package com.example.xvideos.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.xvideos.R;
import com.example.xvideos.model.SinhVien;

import java.util.ArrayList;

public class SinhVienAdapter extends RecyclerView.Adapter<SinhVienAdapter.SinhVienHolder> {
    private ArrayList<SinhVien> list;
    private LayoutInflater inflater;
    public SinhVienAdapter(LayoutInflater inflater) {
        this.inflater = inflater;
    }


    public ArrayList<SinhVien> getList() {
        return list;
    }
    public void setList(ArrayList<SinhVien> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public SinhVienHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_sinhvien,parent,false);
        return new SinhVienHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SinhVienHolder holder, int position) {
        holder.bindView(list.get(position));
//        if (listener!=null){
//            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    listener.onSinhVienClick(list.get(position));
//                }
//            });
//            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
//                @Override
//                public boolean onLongClick(View v) {
//                    listener.onSinhVienLongClick(list.get(position),position);
//                    return true;
//                }
//            });
//        }

    }

    @Override
    public int getItemCount() {
        return list==null? 0: list.size();
    }

    public class SinhVienHolder extends RecyclerView.ViewHolder{
        private TextView tenSV;
        private TextView maSV;
        private TextView ngaySinh;
        private TextView que;
        private CheckBox nam1;
        private CheckBox nam2;
        private CheckBox nam3;
        private CheckBox nam4;

        public SinhVienHolder(@NonNull View iteamView){
            super(iteamView);
            maSV = iteamView.findViewById(R.id.tv_masv);
            tenSV = iteamView.findViewById(R.id.tv_tensv);
            ngaySinh = iteamView.findViewById(R.id.tv_date);
            que = iteamView.findViewById(R.id.tv_que);
            nam1 = iteamView.findViewById(R.id.check_nam1);
            nam2 = iteamView.findViewById(R.id.check_nam2);
            nam3 = iteamView.findViewById(R.id.check_nam3);
            nam4 = iteamView.findViewById(R.id.check_nam4);
        }

        public void bindView(SinhVien sinhVien){
            tenSV.setText(sinhVien.getTenSV());
            que.setText(sinhVien.getQue());
            maSV.setText(sinhVien.getMaSv()+" ");
            ngaySinh.setText(sinhVien.getNgaySinh());
            nam1.setChecked(sinhVien.isNam1());
            nam2.setChecked(sinhVien.isNam2());
            nam3.setChecked(sinhVien.isNam3());
            nam4.setChecked(sinhVien.isNam4());
        }
    }

    public interface SinhVienClickListener{
        void onSinhVienClick(SinhVien sinhVien);
        void onSinhVienLongClick(SinhVien sinhVien, int pos);
    }

}
