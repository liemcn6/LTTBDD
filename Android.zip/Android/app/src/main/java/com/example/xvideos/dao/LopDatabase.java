package com.example.xvideos.dao;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.xvideos.model.Lop;
import com.example.xvideos.model.SinhVien;

@Database(entities = {Lop.class}, version = 1, exportSchema = false)
public abstract class LopDatabase extends RoomDatabase {
    public abstract LopDao lopDao();
}
