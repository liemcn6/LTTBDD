package com.example.xvideos.ui;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.xvideos.R;
import com.example.xvideos.adapter.SinhVienAdapter;
import com.example.xvideos.dao.SinhVienDao;
import com.example.xvideos.dao.SinhVienDatabase;
import com.example.xvideos.model.SinhVien;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class SinhVienActivity extends AppCompatActivity implements View.OnClickListener {
    private ArrayList<SinhVien> list;
    private FloatingActionButton btnAdd;
    private RecyclerView recyclerView;
    private SinhVienDatabase database;
    private SinhVienAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sinhvien);
        database = Room.databaseBuilder(getApplicationContext(),SinhVienDatabase.class,"SinhVien.DB").allowMainThreadQueries().build();
        initView();
    }

    private void initView() {
        recyclerView = findViewById(R.id.rv_sinhvien);
        adapter = new SinhVienAdapter(getLayoutInflater());
        loadData();
        recyclerView.setAdapter(adapter);
        btnAdd = findViewById(R.id.btn_add);
        btnAdd.setOnClickListener(this);
    }

    private void loadData() {
        list =  (ArrayList<SinhVien>) database.sinhVienDao().getAll();
        adapter.setList(list);

    }
    private void displayDialog(SinhVien sinhVien){
        View view = getLayoutInflater().inflate(R.layout.add_sinhvien,null);
        EditText edtTen = view.findViewById(R.id.edt_dialog_ten);
        EditText edtNgaySinh = view.findViewById(R.id.edt_dialog_ngaysinh);
        EditText edtQue = view.findViewById(R.id.edt_dialog_que);
        CheckBox nam1 = view.findViewById(R.id.check_dialog_nam1);
        CheckBox nam2 = view.findViewById(R.id.check_dialog_nam2);
        CheckBox nam3 = view.findViewById(R.id.check_dialog_nam3);
        CheckBox nam4 = view.findViewById(R.id.check_dialog_nam4);
        DatePicker datePicker = view.findViewById(R.id.datePicker);
        Button btnDate = view.findViewById(R.id.btn_pick);
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtNgaySinh.setText(datePicker.getDayOfMonth() + "/" + (datePicker.getMonth()+1) + "/" + datePicker.getYear());

            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view);
        if (sinhVien == null){
            builder.setTitle("Thêm Sinh Viên ");
            builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    return;
                }
            });
            builder.setPositiveButton("Thêm", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int i) {
                    String name = edtTen.getText().toString();
                    String date = edtNgaySinh.getText().toString();
                    String diachi = edtQue.getText().toString();
                    boolean nam1xxx= nam1.isChecked();
                    boolean nam2xxx= nam2.isChecked();
                    boolean nam3xxx= nam3.isChecked();
                    boolean nam4xxx= nam4.isChecked();


                    if (name.isEmpty() || date.isEmpty()||diachi.isEmpty()){
                        return;
                    } else {
                        SinhVien sinhVien1 = new SinhVien(name,nam1xxx,nam2xxx,nam3xxx,nam4xxx,diachi,date);
                        database.sinhVienDao().insert(sinhVien1);
                        loadData();
                    }
                }
            });
        }
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {
        displayDialog(null);
    }
}
