package com.example.xvideos.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Lop {
    @PrimaryKey(autoGenerate = true) private int malop;
    @ColumnInfo
    private String tenlop;
    @ColumnInfo
    private String mota;

    public Lop(String tenlop, String mota) {
        this.tenlop = tenlop;
        this.mota = mota;
    }

    public int getMalop() {
        return malop;
    }

    public void setMalop(int malop) {
        this.malop = malop;
    }

    public String getTenlop() {
        return tenlop;
    }

    public void setTenlop(String tenlop) {
        this.tenlop = tenlop;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }
}
