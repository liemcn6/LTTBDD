package com.example.xvideos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.xvideos.model.Lop;
import com.example.xvideos.ui.LopActivity;
import com.example.xvideos.ui.SinhVienActivity;

public class MainActivity extends AppCompatActivity {
    private Button btnSinhVien, btnlop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ititView();
    }

    private void ititView() {
        btnSinhVien = findViewById(R.id.btn_sinhvien);
        btnlop = findViewById(R.id.btn_lop);
        btnlop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LopActivity.class);
                startActivity(intent);
            }
        });
        btnSinhVien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SinhVienActivity.class);
                startActivity(intent);
            }
        });
    }
}