package com.example.xvideos.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class SinhVien {

    @PrimaryKey(autoGenerate = true) private int maSv;
    @ColumnInfo
    private String tenSV;
    @ColumnInfo private boolean nam1;
    @ColumnInfo private boolean nam2;
    @ColumnInfo private boolean nam3;
    @ColumnInfo private boolean nam4;
    @ColumnInfo private String que;
    @ColumnInfo private String ngaySinh;

    public SinhVien(String tenSV, boolean nam1, boolean nam2, boolean nam3, boolean nam4, String que, String ngaySinh) {
        this.tenSV = tenSV;
        this.nam1 = nam1;
        this.nam2 = nam2;
        this.nam3 = nam3;
        this.nam4 = nam4;
        this.que = que;
        this.ngaySinh = ngaySinh;
    }

    public int getMaSv() {
        return maSv;
    }

    public void setMaSv(int maSv) {
        this.maSv = maSv;
    }

    public String getTenSV() {
        return tenSV;
    }

    public void setTenSV(String tenSV) {
        this.tenSV = tenSV;
    }

    public boolean isNam1() {
        return nam1;
    }

    public void setNam1(boolean nam1) {
        this.nam1 = nam1;
    }

    public boolean isNam2() {
        return nam2;
    }

    public void setNam2(boolean nam2) {
        this.nam2 = nam2;
    }

    public boolean isNam3() {
        return nam3;
    }

    public void setNam3(boolean nam3) {
        this.nam3 = nam3;
    }

    public boolean isNam4() {
        return nam4;
    }

    public void setNam4(boolean nam4) {
        this.nam4 = nam4;
    }

    public String getQue() {
        return que;
    }

    public void setQue(String que) {
        this.que = que;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }
}
