package com.example.xvideos.dao;

import androidx.cardview.widget.CardView;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.xvideos.model.Lop;
import com.example.xvideos.model.SinhVien;

import java.util.List;

@Dao
public interface LopDao {
    @Query("select * from Lop")
    List<Lop> getAll();

    @Insert
    void insert( Lop lop );

    @Update
    void update(Lop lop);

    @Delete
    void delete(Lop lop);
}
