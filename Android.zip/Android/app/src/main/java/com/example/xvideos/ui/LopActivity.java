package com.example.xvideos.ui;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.xvideos.R;
import com.example.xvideos.adapter.LopAdapter;
import com.example.xvideos.adapter.SinhVienAdapter;
import com.example.xvideos.dao.LopDatabase;
import com.example.xvideos.dao.SinhVienDatabase;
import com.example.xvideos.model.Lop;
import com.example.xvideos.model.SinhVien;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class LopActivity extends AppCompatActivity implements View.OnClickListener {
    private ArrayList<Lop> list;
    private FloatingActionButton btnAdd;
    private RecyclerView recyclerView;
    private LopDatabase database;
    private LopAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lop);
        database = Room.databaseBuilder(getApplicationContext(),LopDatabase.class,"Lop.DB").allowMainThreadQueries().build();
        initView();
    }

    private void initView() {
        recyclerView = findViewById(R.id.rv_lop);
        adapter = new LopAdapter(getLayoutInflater());
        loadData();
        recyclerView.setAdapter(adapter);
        btnAdd = findViewById(R.id.btn_add_lop);
        btnAdd.setOnClickListener(this);
    }

    private void loadData() {
        list =  (ArrayList<Lop>) database.lopDao().getAll();
        adapter.setList(list);
    }

    private void displayDialog(Lop lop ) {
        View view = getLayoutInflater().inflate(R.layout.add_lop, null);
        EditText edtTen = view.findViewById(R.id.edt_dialog_ten_op);
        EditText edtMota = view.findViewById(R.id.edt_dialog_mota);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view);
        if (lop==null) {
            builder.setTitle("Them ớp học");
            builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    return;
                }
            });
            builder.setPositiveButton("Thêm", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String name = edtTen.getText().toString();
                    String mota = edtMota.getText().toString();
                    if (name.isEmpty() || mota.isEmpty()) {
                        return;
                    } else {
                        Lop lop1 = new Lop(name, mota);
                        database.lopDao().insert(lop1);
                        loadData();
                    }
                }
            });
        }
           AlertDialog alertDialog = builder.create();
           alertDialog.show();

    }
    @Override
    public void onClick(View v) {
     displayDialog(null);
    }
}
