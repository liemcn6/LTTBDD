package com.example.xvideos.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.xvideos.R;
import com.example.xvideos.model.Lop;
import com.example.xvideos.model.SinhVien;

import java.util.ArrayList;

public class LopAdapter extends RecyclerView.Adapter<LopAdapter.LopHolder>{
    private ArrayList<Lop> list;
    private LayoutInflater inflater;
    public LopAdapter(LayoutInflater inflater) {
        this.inflater = inflater;
    }


    public ArrayList<Lop> getList() {
        return list;
    }

    public void setList(ArrayList<Lop> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LopHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_lop,parent,false);
        return new LopHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LopHolder holder, int position) {
        holder.bindView(list.get(position));

    }

    @Override
    public int getItemCount() {
        return list==null? 0: list.size();
    }

    public class LopHolder extends RecyclerView.ViewHolder{
        private TextView tenLop;
        private TextView maLop;
        private TextView moTa;

        public LopHolder(@NonNull View iteamView){
            super(iteamView);
            maLop = iteamView.findViewById(R.id.tv_malop);
            tenLop = iteamView.findViewById(R.id.tv_tenlop);
            moTa = iteamView.findViewById(R.id.tv_mota);
        }

        public void bindView(Lop lop){
            tenLop.setText(lop.getTenlop());
           maLop.setText(lop.getMalop()+" ");
            moTa.setText(lop.getMota());
        }
    }

}
