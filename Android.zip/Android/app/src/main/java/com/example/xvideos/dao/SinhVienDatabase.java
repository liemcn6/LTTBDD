package com.example.xvideos.dao;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.xvideos.model.Lop;
import com.example.xvideos.model.SinhVien;

@Database(entities = {SinhVien.class}, version = 1, exportSchema = false)
public abstract class SinhVienDatabase extends RoomDatabase {
    public abstract SinhVienDao sinhVienDao();
}
